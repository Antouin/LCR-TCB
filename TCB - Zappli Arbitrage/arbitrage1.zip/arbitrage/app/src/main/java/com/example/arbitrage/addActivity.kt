package com.example.arbitrage

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintSet.Layout
import androidx.drawerlayout.widget.DrawerLayout
import android.widget.Spinner
import android.widget.TextView
import com.google.android.material.navigation.NavigationView

class addActivity: AppCompatActivity(){

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        val confirmer = findViewById<Button>(R.id.btnconfirm)
        confirmer.setOnClickListener {
            val intent = Intent(this,thirdActivity::class.java)
            startActivity(intent)
        }

        val gameModeSpinner = findViewById<Spinner>(R.id.gameModeSpinner)
        val descriptionText = findViewById<TextView>(R.id.descriptionText)

        val gameModes = resources.getStringArray(R.array.game_modes)
        val gameDescriptions = resources.getStringArray(R.array.game_description)


        // Charger les options depuis strings.xml
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, gameModes)
        gameModeSpinner.adapter = adapter

        gameModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                descriptionText.text = gameDescriptions[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                descriptionText.text = "Sélectionner un mode de jeux"
            }
        }

        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)

        setSupportActionBar(toolbar)

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId){
                R.id.nav_home -> {
                    val intent = Intent(this, SecondActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_add -> {
                    val intent = Intent(this, addActivity::class.java)
                    startActivity(intent)
                }
            }
            drawerLayout.closeDrawers()
            true
        }
    }

}