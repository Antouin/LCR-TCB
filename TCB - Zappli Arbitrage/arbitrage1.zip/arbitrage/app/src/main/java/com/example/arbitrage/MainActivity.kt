package com.example.arbitrage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.UserHandle
import android.widget.EditText
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.arbitrage.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val loginbutton = findViewById<Button>(R.id.button)
        loginbutton.setOnClickListener {
            showLoginDialog()
        }

    }

    private fun showLoginDialog(){
        val dialogView = layoutInflater.inflate(R.layout.dialog_login, null)
        val usernameInput = dialogView.findViewById<EditText>(R.id.editTextUsername)
        val passwordInput = dialogView.findViewById<EditText>(R.id.editTextUsername)
        val btnLogin = dialogView.findViewById<Button>(R.id.btnLogin)
        val btnCancel = dialogView.findViewById<ImageButton>(R.id.imageButton)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

            btnLogin.setOnClickListener{
                val intent = Intent(this,SecondActivity::class.java)
                val username = usernameInput.text.toString()
                val password = passwordInput.text.toString()
                leLogin(username, password, intent)
                dialog.dismiss()
            }
            btnCancel.setOnClickListener{
                dialog.dismiss()
            }

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }

    private fun leLogin(username: String, password: String, intent: Intent){
        if (username == "test" && password == "test"){
            startActivity(intent)
            Toast.makeText(this,"Connexion réussie ! ", Toast.LENGTH_SHORT).show()
        }else {
            Toast.makeText(this,"Identifiant ou mot de passe incorrect.", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * A native method that is implemented by the 'arbitrage' native library,
     * which is packaged with this application.
     */
    external fun stringFromJNI(input: String): String

    companion object {
        // Used to load the 'arbitrage' library on application startup.
        init {
            System.loadLibrary("arbitrage")
        }
    }
}