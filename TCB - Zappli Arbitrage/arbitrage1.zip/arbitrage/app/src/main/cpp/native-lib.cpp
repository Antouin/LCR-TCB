#include <jni.h>
#include <string>

using namespace std;
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_arbitrage_MainActivity_stringFromJNI(JNIEnv* env, jobject,jstring input/* this */) {
    const char* userInput = env->GetStringUTFChars(input, 0);
    string message ="Vous avez saisi : ";
    message += userInput;

    env->ReleaseStringUTFChars(input, userInput);
    return env->NewStringUTF(message.c_str());
}
