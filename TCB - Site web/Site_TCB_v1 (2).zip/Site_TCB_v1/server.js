const express = require('express');
const { createServer } = require('node:http');
const { join } = require('node:path');
const { Server } = require('socket.io');
const morgan = require('morgan');
const twig = require('twig');
const path = require('node:path');
const bodyParser = require('body-parser');
const mysql = require('mysql2'); // Ajout de MySQL

const app = express();
const server = createServer(app);
const io = new Server(server);

// Middleware pour parser les données des formulaires
app.use(bodyParser.urlencoded({ extended: true }));

// Charger images, styles et scripts via Express
app.use(express.static(path.join(__dirname, 'public')));

// Logger HTTP avec Morgan
app.use(morgan("dev"));

// Port d'écoute
const PORT = 3000;

// Configuration de Twig
app.set('view engine', 'twig');
app.set('views', path.join(__dirname, 'views'));

// Connexion à MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // * utilisateur MySQL
    password: 'willy9105',  // * mot de passe MySQL
    database: 'tcb_projet_tennis'
});

db.connect((err) => {
    if (err) {
        console.error('Erreur de connexion à MySQL:', err);
    } else {
        console.log('Connecté à la base de données MySQL');
    }
});

// Route principale (Accueil)
app.get('/', (req, res) => {
    res.render('index.html.twig');
});

// Route pour afficher la page de connexion
app.get('/login', (req, res) => {
    res.render('login.html.twig');
});

// Route pour traiter la connexion
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (username === "coach" && password === "coach") {
        res.redirect(`/accueil?username=${encodeURIComponent(username)}`);
    } else {
        res.render('login.html.twig', { error: "Identifiant ou mot de passe incorrect." });
    }
});

// Route pour afficher la page d'accueil après connexion
app.get('/accueil', (req, res) => {
    const username = req.query.username || "Utilisateur";
    res.render('accueil.html.twig', { username });
});
// Route de déconnexion (redirige vers l'accueil)
app.get('/logout', (req, res) => {
    res.redirect('/');
});

// Route pour afficher la page de consultation des joueurs
app.get('/consultation', (req, res) => {
    if (!db || !db.state || db.state === 'disconnected') {
        console.warn("Connexion MySQL indisponible, affichage de joueurs fictifs.");
        
        // Liste de joueurs fictifs (temporaire)
        const joueursFictifs = [
            { id: 1, nom: "Menn", prenom: "Antoine" },
            { id: 2, nom: "Donnart", prenom: "Alexis" },
            { id: 3, nom: "Douarin", prenom: "Maël" },
            { id: 4, nom: "Gabarrou--Thimothée", prenom: "Andy" }
        ];

        return res.render('consultation.html.twig', { joueurs: joueursFictifs });
    }

    // Si MySQL est dispo, récupérer les vrais joueurs
    db.query('SELECT * FROM joueurs', (err, result) => {
        if (err) {
            console.error('Erreur lors de la récupération des joueurs:', err);
            res.status(500).send('Erreur interne du serveur');
        } else {
            res.render('consultation.html.twig', { joueurs: result });
        }
    });
});


// Route pour traiter la sélection d’un joueur
app.post('/consultation-joueur', (req, res) => {
    const joueurId = req.body.joueur;

    db.query('SELECT * FROM joueurs WHERE id = ?', [joueurId], (err, result) => {
        if (err || result.length === 0) {
            res.status(404).send("Joueur non trouvé");
        } else {
            res.send(`Consultation des statistiques du joueur : ${result[0].nom} ${result[0].prenom}`);
        }
    });
});

/* Émission de l'heure toutes les 2 secondes via Socket.io
setInterval(() => {
    const heure = new Date().toLocaleTimeString();
    console.log(`Heure envoyée : ${heure}`);
    io.emit("canal1", heure);
}, 2000);*/

// Gestion des connexions Socket.io
io.on("connection", (socket) => {
    console.log("Un utilisateur s'est connecté.");
    socket.on("deconnection", () => {
        console.log("Un utilisateur s'est déconnecté.");
    });
});

// Lancement du serveur
server.listen(PORT, () => {
    console.log(`Serveur en écoute sur http://localhost:${PORT}`);
});
