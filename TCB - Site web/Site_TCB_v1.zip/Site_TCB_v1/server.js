const express = require('express');
const { createServer } = require('node:http');
const { join } = require('node:path');
const { Server } = require('socket.io');
const morgan = require('morgan');
const twig = require('twig');
const path = require('node:path');
const bodyParser = require('body-parser');

const app = express();
const server = createServer(app);
const io = new Server(server);

// Middleware pour parser les données des formulaires
app.use(bodyParser.urlencoded({ extended: true }));

// Charger images, styles et scripts via Express
app.use(express.static(path.join(__dirname, 'public')));

// Logger HTTP avec Morgan
app.use(morgan("dev"));

// Port d'écoute
const PORT = 3000;

// Configuration de Twig
app.set('view engine', 'twig');
app.set('views', path.join(__dirname, 'views')); // Vérifie que le dossier "views" existe

// Vérifie le chemin du dossier views (DEBUG)
console.log("Dossier views configuré : ", path.join(__dirname, 'views'));

// Route principale (Accueil)
app.get('/', (req, res) => {
    res.render('index.html.twig'); // Twig sait quel fichier charger
});

// Route pour afficher la page de connexion
app.get('/login', (req, res) => {
    res.render('login.html.twig');
});

// Route pour traiter la connexion
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    console.log(`Identifiant : ${username}`);
    console.log(`Mot de passe : ${password}`);

    // Simulation d'une authentification basique (à remplacer par une base de données)
    if (username === "admin" && password === "1234") {
        res.send("Connexion réussie !");
    } else {
        res.send("Échec de la connexion. Vérifiez vos identifiants.");
    }
});

// Émission de l'heure toutes les 2 secondes via Socket.io
setInterval(() => {
    const heure = new Date().toLocaleTimeString();
    console.log(`Heure envoyée : ${heure}`);
    io.emit("canal1", heure);
}, 2000);

// Gestion des connexions Socket.io
io.on("connection", (socket) => {
    console.log("Un utilisateur s'est connecté.");
    socket.on("deconnection", () => {
        console.log("Un utilisateur s'est déconnecté.");
    });
});

// Lancement du serveur
server.listen(PORT, () => {
    console.log(`Serveur en écoute sur http://localhost:${PORT}`);
});
