const express = require('express');
const { createServer } = require('node:http');
const { join } = require('node:path');
const { Server } = require('socket.io');
const morgan = require('morgan');
const twig = require('twig');
const path = require('node:path');
const bodyParser = require('body-parser');
const session = require('express-session'); 
const mysql = require('mysql2');

const app = express();
const server = createServer(app);
const io = new Server(server);

app.use(bodyParser.urlencoded({ extended: true }));

// Charger les fichiers statiques (images, styles, scripts)
app.use(express.static(path.join(__dirname, 'public')));

// Logger HTTP avec Morgan
app.use(morgan("dev"));

// Configuration de Twig
app.set('view engine', 'twig');
app.set('views', path.join(__dirname, 'views'));

// Configuration des sessions
app.use(session({
    secret: 'secret_key', 
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 3600000 } // 1h de session
}));
// Connexion à MySQL
const db = mysql.createConnection({
    host: 'mysql-lcr-mm.alwaysdata.net',
    user: 'lcr-mm',
    password: 'Azerty.1@',
    database: 'lcr-mm_tcb2'
});

db.connect((err) => {
    if (err) {
        console.error('Erreur de connexion à MySQL:', err);
        return;
    }
    console.log('Connexion à MySQL réussie');
});
const PORT = 3000;

// Route principale (Accueil)
app.get('/', (req, res) => {
    res.render('index.html.twig');
});

// Route de connexion
app.get('/login', (req, res) => {
    res.render('login.html.twig');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log(`Tentative de connexion: ${username}`);

    if (username === "entraineur" && password === "entraineur") {
        req.session.role = "entraineur";
        console.log("Utilisateur connecté en tant qu'entraineur");
        res.redirect('/accueil');
    } else if (username === "joueur" && password === "joueur") {
        req.session.role = "joueur";
        console.log("Utilisateur connecté en tant que joueur");
        res.redirect('/accueil-joueur');
    } else if (username === "accompagnateur" && password === "accompagnateur") {
        req.session.role = "accompagnateur";
        console.log("Utilisateur connecté en tant qu'accompagnateur");
        res.redirect('/accueil'); 
    } else {
        console.log("Échec de connexion");
        res.render('login.html.twig', { error: "Identifiant ou mot de passe incorrect." });
    }
});


// Middleware pour vérifier si l'utilisateur est connecté
function checkAuth(req, res, next) {
    if (!req.session.role) {
        console.log("Accès refusé : utilisateur non connecté.");
        return res.redirect('/login');
    }
    console.log(`Accès autorisé - Rôle: ${req.session.role}`);
    next();
}

// Route d'accueil
app.get('/accueil', checkAuth, (req, res) => {
    if (req.session.role === "joueur") {
        return res.redirect('/accueil-joueur');
    }
    res.render('accueil.html.twig', { role: req.session.role });
});

// Route des statistiques coach (choix du joueur)
app.get('/statistiques_coach', checkAuth, (req, res) => {
    if (req.session.role !== "entraineur") {
        return res.status(403).send("Accès interdit");
    }

    const sql = "SELECT id_personne, nom, prenom FROM Personnes";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("Erreur lors de la récupération des joueurs :", err);
            return res.status(500).send("Erreur serveur");
        }

        console.log("Joueurs récupérés :", results); // Vérification console

        res.render('statistiques_coach.html.twig', { joueurs: results });
    });
});


// Route des statistiques coach (détails d'un joueur)
app.get('/statistiques_coach/:id_joueur', checkAuth, (req, res) => {
    if (req.session.role !== "entraineur") {
        return res.status(403).send("Accès interdit");
    }
    
    const id_joueur = req.params.id_joueur;

    // Données fictives basées sur la table Feuille_match
    /*const joueur = {
        id: id_joueur,
        nom: "NomJoueur" + id_joueur,
        prenom: "PrenomJoueur" + id_joueur,
        stats: [
            { ace: 3, winner: 10, faute: 5, double_faute: 1, smash: 2, volee: 4, let: 1, abandon: 0 },
            { ace: 5, winner: 12, faute: 7, double_faute: 2, smash: 3, volee: 5, let: 0, abandon: 1 }
        ]
    };*/

    res.render('statistiques_coach.html.twig', { joueur });
});
app.get('/comparaison', checkAuth, (req, res) => {
    if (req.session.role !== "entraineur") {
        return res.status(403).send("Accès interdit");
    }

    const joueur1 = req.query.joueur1;
    const joueur2 = req.query.joueur2;

    if (!joueur1 || !joueur2) {
        return res.status(400).send("Sélectionnez deux joueurs pour comparer.");
    }

    const sql = `
        SELECT p.id_personne, p.nom, p.prenom, 
           f.ace, f.winner, f.faute, f.double_faute, 
           f.amorti, f.smash, f.volee, f.abandon
    FROM Personnes p
    LEFT JOIN Feuille_match f ON p.id_personne = f.id_personne
    WHERE p.id_personne IN (?, ?)
    `;

    db.query(sql, [joueur1, joueur2], (err, results) => {
        if (err) {
            console.error('Erreur lors de la récupération des données :', err);
            return res.status(500).send("Erreur serveur");
        }

        // Trier les résultats par joueur
        const dataJoueur1 = results.filter(j => j.id_personne == joueur1);
        const dataJoueur2 = results.filter(j => j.id_personne == joueur2);
        
        const comparaison = {
            joueur1: {
                id: joueur1,
                nom: dataJoueur1.length ? dataJoueur1[0].nom : "Inconnu",
                prenom: dataJoueur1.length ? dataJoueur1[0].prenom : "Inconnu",
                stats: dataJoueur1.map(j => ({
                    ace: j.ace, winner: j.winner, faute: j.faute,
                    double_faute: j.double_faute, amorti: j.amorti,
                    smash: j.smash, volee: j.volee, abandon: j.abandon
                }))
            },
            joueur2: {
                id: joueur2,
                nom: dataJoueur2.length ? dataJoueur2[0].nom : "Inconnu",
                prenom: dataJoueur2.length ? dataJoueur2[0].prenom : "Inconnu",
                stats: dataJoueur2.map(j => ({
                    ace: j.ace, winner: j.winner, faute: j.faute,
                    double_faute: j.double_faute, amorti: j.amorti,
                    smash: j.smash, volee: j.volee, abandon: j.abandon
                }))
            }
        };
        
        
        

        res.render('comparaison.html.twig', { comparaison });
    });
});
// Route pour la saisie des données
app.get('/saisie-donnees', checkAuth, (req, res) => {
    if (req.session.role !== "accompagnateur") {
        return res.status(403).send("Accès interdit");
    }

    const sql = "SELECT id_personne, nom, prenom FROM Personnes";

    db.query(sql, (err, joueurs) => {
        if (err) {
            console.error("Erreur lors de la récupération des joueurs :", err);
            return res.status(500).send("Erreur serveur");
        }
        res.render('saisie-donnees.html.twig', { joueurs });
    });
});
app.post('/ajouter-feuille-match', checkAuth, (req, res) => {
    if (req.session.role !== "accompagnateur") {
        return res.status(403).send("Accès interdit");
    }

    // Affichage des données reçues
    console.log("🔹 Données reçues :", req.body);

    const { id_personne, ace, winner, faute, double_faute, amorti, smash, volee, abandon } = req.body;

    // Vérification des valeurs reçues
    if (!id_personne || isNaN(ace) || isNaN(winner) || isNaN(faute) || isNaN(double_faute) || 
        isNaN(amorti) || isNaN(smash) || isNaN(volee) || isNaN(abandon)) {
        console.error(" Données invalides :", req.body);
        return res.status(400).send("Données invalides. Vérifiez les champs.");
    }

    const sql = `INSERT INTO Feuille_match (id_personne, ace, winner, faute, double_faute, amorti, smash, volee, abandon) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(sql, [id_personne, ace, winner, faute, double_faute, amorti, smash, volee, abandon], (err, result) => {
        if (err) {
            console.error(" Erreur MySQL lors de l'ajout de la feuille de match :", err);
            return res.status(500).send("Erreur serveur : " + err.message);
        }
        console.log(" Feuille de match ajoutée avec succès !", result);
        res.redirect('/saisie-donnees'); // Recharge la page après ajout
    });
});




// Route des statistiques joueur
app.get('/statistiques_joueur', checkAuth, (req, res) => {
    if (req.session.role !== "joueur") {
        return res.status(403).send("Accès interdit");
    }

    const id_joueur = req.session.id_personne;
    db.query("SELECT * FROM Feuille_match WHERE id_personne = ?", [id_joueur], (err, stats) => {
        if (err) {
            console.error("Erreur MySQL:", err);
            return res.status(500).send("Erreur serveur");
        }
        res.render('statistiques_joueur.html.twig', { statistiques: stats });
    });
});


// Route de déconnexion
app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/');
    });
});

// Gestion des erreurs 404
app.use((req, res, next) => {
    console.log(`404 - Fichier non trouvé : ${req.url}`);
    res.status(404).send("Page non trouvée.");
});

// Lancement du serveur
server.listen(PORT, () => {
    console.log(`Serveur en écoute sur http://localhost:${PORT}`);
});
