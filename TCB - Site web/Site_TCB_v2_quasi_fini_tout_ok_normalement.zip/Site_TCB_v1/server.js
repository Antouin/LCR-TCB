const express = require('express');
const { createServer } = require('node:http');
const { join } = require('node:path');
const { Server } = require('socket.io');
const morgan = require('morgan');
const twig = require('twig');
const path = require('node:path');
const bodyParser = require('body-parser');
const session = require('express-session'); 
const mysql = require('mysql2');

const app = express();
const server = createServer(app);
const io = new Server(server);
// middleware pour la déco
app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '-1');
    next();
});
app.use(express.json()); // Permet de traiter le JSON
app.use(express.urlencoded({ extended: true })); // Pour traiter les formulaires

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Charger les fichiers statiques (images, styles, scripts)
app.use(express.static(path.join(__dirname, 'public')));

// Logger HTTP avec Morgan
app.use(morgan("dev"));

// Configuration de Twig
app.set('view engine', 'twig');
app.set('views', path.join(__dirname, 'views'));

// Configuration des sessions
app.use(session({
    secret: 'secret_key', 
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 3600000 } // 1h de session
}));
// Connexion à MySQL
const db_config = {
    host: 'mysql-lcr-mm.alwaysdata.net',
    user: 'lcr-mm',
    password: 'Azerty.1@',
    database: 'lcr-mm_tcb2'
};

let db;

function handleDisconnect() {
    db = mysql.createConnection(db_config);

    db.connect(function(err) {
        if (err) {
            console.error('Erreur de connexion à MySQL:', err);
            setTimeout(handleDisconnect, 2000); // attend 2s avant retry
        } else {
            console.log("Connexion à MySQL réussie !");
        }
    });

    db.on('error', function(err) {
        console.error('Erreur MySQL :', err);
        if (err.code === 'PROTOCOL_CONNECTION_LOST' || err.code === 'ETIMEDOUT') {
            handleDisconnect(); // reconnecte automatiquement
        } else {
            throw err;
        }
    });
}

handleDisconnect(); // Lancer la première connexion

db.connect((err) => {
    if (err) {
        console.error('Erreur de connexion à MySQL:', err);
        return;
    }
    console.log('Connexion à MySQL réussie');
});
const PORT = 3000;

// Route principale (Accueil)
app.get('/', (req, res) => {
    res.render('index.html.twig');
});
const bcrypt = require("bcrypt");

app.post("/register", async (req, res) => {
    console.log("Données reçues :", req.body); // Vérification des données envoyées

    const { nom, prenom, date_naissance, role, email, telephone, mot_de_passe, confirm_mot_de_passe } = req.body;

    // Vérification des champs obligatoires
    if (!nom || !prenom || !date_naissance || !role || !email || !telephone || !mot_de_passe || !confirm_mot_de_passe) {
        console.log(" Erreur: Tous les champs ne sont pas remplis.");
        return res.json({ success: false, error: "Tous les champs sont obligatoires." });
    }

    // Vérification de la correspondance des mots de passe
    if (mot_de_passe !== confirm_mot_de_passe) {
        console.log(" Erreur: Les mots de passe ne correspondent pas.");
        return res.json({ success: false, error: "Les mots de passe ne correspondent pas." });
    }

    // Déterminer le statut en fonction du rôle
    let statut = 1; // Joueur par défaut
    if (role === "Entraîneur") statut = 3;
    if (role === "Accompagnateur") statut = 2;

    try {
        // Vérifier si l'email existe déjà
        const checkEmailSql = "SELECT * FROM Personnes WHERE email = ?";
        db.query(checkEmailSql, [email], async (err, result) => {
            if (err) {
                console.error(" Erreur MySQL:", err);
                return res.json({ success: false, error: "Erreur serveur." });
            }

            if (result.length > 0) {
                console.log(" Erreur: Email déjà utilisé.");
                return res.json({ success: false, error: "Cette adresse e-mail est déjà utilisée." });
            }

            // **Faire le hashage AVANT d'exécuter la requête**
            const saltRounds = 10;
            bcrypt.hash(mot_de_passe, saltRounds, (err, hashedPassword) => {
                if (err) {
                    console.error(" Erreur lors du hachage du mot de passe:", err);
                    return res.json({ success: false, error: "Erreur serveur." });
                }

                // **Insérer dans la base avec le mot de passe bien haché**
                const sql = `
                    INSERT INTO Personnes (nom, prenom, date_naissance, role, email, telephone, date_inscription, statut, mot_de_passe)
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?)`;

                db.query(sql, [nom, prenom, date_naissance, role, email, telephone, statut, hashedPassword], (err, result) => {
                    if (err) {
                        console.error(" Erreur lors de l'inscription:", err);
                        return res.json({ success: false, error: "Erreur serveur lors de l'inscription." });
                    }
                    console.log(" Compte créé avec succès !");
                    return res.json({ success: true });
                });
            });
        });
    } catch (error) {
        console.error(" Erreur interne:", error);
        return res.json({ success: false, error: "Une erreur est survenue." });
    }
});



// Route de connexion
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    console.log(`Tentative de connexion : ${email}`);

    if (!email || !password) {
        return res.json({ success: false, error: "Veuillez remplir tous les champs." });
    }

    // Vérifier si l'utilisateur existe
    const sql = "SELECT id_personne, email, mot_de_passe, statut FROM Personnes WHERE email = ?";
    db.query(sql, [email], async (err, results) => {
        if (err) {
            console.error("Erreur MySQL :", err);
            return res.json({ success: false, error: "Erreur serveur." });
        }

        if (results.length === 0) {
            return res.json({ success: false, error: "Adresse e-mail ou mot de passe incorrect." });
        }

        const user = results[0];


    bcrypt.compare(password, user.mot_de_passe, (err, result) => {
    if (err) {
        console.error("Erreur lors de la comparaison du mot de passe :", err);
        return res.json({ success: false, error: "Erreur serveur." });
    }
    
    console.log("Résultat bcrypt.compare() :", result);
    
    if (!result) {
        return res.json({ success: false, error: "Adresse e-mail ou mot de passe incorrect." });
    }

    // Stocker les infos en session
    req.session.userId = user.id_personne;
    req.session.statut = user.statut;

    console.log(`Utilisateur connecté avec statut : ${user.statut}`);

    // Redirection en fonction du statut
    let redirectUrl = "/";
    if (user.statut === 1) redirectUrl = "/accueil-joueur";
    if (user.statut === 2) redirectUrl = "/accueil";
    if (user.statut === 3) redirectUrl = "/accueil";

    req.session.save(err => {
        if (err) {
            console.error("Erreur lors de l'enregistrement de la session :", err);
            return res.json({ success: false, error: "Erreur serveur." });
        }
        console.log(`Redirection vers : ${redirectUrl}`);
        return res.json({ success: true, redirect: redirectUrl });
    });
});
    });
});






// Middleware pour vérifier si l'utilisateur est connecté
function checkAuth(req, res, next) {
    if (!req.session.statut) {  
        console.log("Accès refusé : utilisateur non connecté.");
        return res.redirect('/login');
    }
    console.log(`Accès autorisé - Statut: ${req.session.statut}`);
    next();
}


// Route d'accueil
app.get('/accueil', checkAuth, (req, res) => {
    console.log(`Accès à la page accueil - Statut : ${req.session.statut}`);

    let role = "";
    if (req.session.statut === 1) {
        role = "joueur";
        return res.redirect('/accueil-joueur');
    } else if (req.session.statut === 2) {
        role = "accompagnateur";
    } else if (req.session.statut === 3) {
        role = "entraineur";
    }

    res.render('accueil.html.twig', { statut: req.session.statut });
});
app.get('/accueil-joueur', checkAuth, (req, res) => {
    if (req.session.statut !== 1) {
        return res.status(403).send("Accès interdit");
    }

    const id = req.session.userId;

    db.query("SELECT nom, prenom FROM Personnes WHERE id_personne = ?", [id], (err, result) => {
        if (err || result.length === 0) {
            console.error("Erreur ou utilisateur non trouvé :", err);
            return res.status(500).send("Erreur serveur");
        }

        const joueur = result[0];
        const username = `${joueur.prenom} ${joueur.nom}`;

        res.render('accueil-joueur.html.twig', { username });
    });
});

// Route des statistiques coach (choix du joueur)
app.get('/statistiques_coach', checkAuth, (req, res) => {
    if (req.session.statut !== 3) { // 3 = Entraîneur
        return res.status(403).send("Accès interdit");
    }

    const sql = "SELECT id_personne, nom, prenom FROM Personnes";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("Erreur lors de la récupération des joueurs :", err);
            return res.status(500).send("Erreur serveur");
        }

        console.log("Joueurs récupérés :", results); // Vérification console

        res.render('statistiques_coach.html.twig', { joueurs: results });
    });
});

app.get('/consultation-joueur', checkAuth, (req, res) => {
    if (req.session.statut !== 3) { // 3 = Entraîneur
        return res.status(403).send("Accès interdit");
    }

    const sql = "SELECT id_personne, nom, prenom FROM Personnes";

    db.query(sql, (err, joueurs) => {
        if (err) {
            console.error("Erreur lors de la récupération des joueurs :", err);
            return res.status(500).send("Erreur serveur");
        }
        res.render('consultation-joueur.html.twig', { joueurs });
    });
});

// Route pour récupérer les statistiques d'un joueur
app.get('/get-feuille-match/:id_personne', checkAuth, (req, res) => {
    if (req.session.statut !== 3) {  // ✅ Seul l'entraîneur (3) est autorisé
        return res.status(403).send("Accès interdit");
    }

    const id_personne = req.params.id_personne;

    const sql = `SELECT * FROM Feuille_match WHERE id_personne = ?`;

    db.query(sql, [id_personne], (err, result) => {
        if (err) {
            console.error("Erreur lors de la récupération des données :", err);
            return res.status(500).json({ error: "Erreur serveur" });
        }

        if (result.length === 0) {
            return res.status(404).json({ error: "Aucune donnée trouvée pour ce joueur" });
        }

        res.json(result);
    });
});
app.get('/get-all-matches-data/:id_personne', checkAuth, (req, res) => {
    if (req.session.statut !== 3) return res.status(403).json({ error: "Accès interdit" });

    const id = req.params.id_personne;
    const sql = "SELECT ace, winner, faute, double_faute, amorti, smash, volee, abandon FROM Feuille_match WHERE id_personne = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            console.error("Erreur SQL pour graphique global :", err);
            return res.status(500).json({ error: "Erreur serveur" });
        }
        res.json(result);
    });
});


// Route des statistiques coach (détails d'un joueur)
app.get('/statistiques_coach', checkAuth, (req, res) => {
    if (req.session.statut !== 3) { // 3 = Entraîneur
        return res.status(403).send("Accès interdit");
    }

    const sql = "SELECT id_personne, nom, prenom FROM Personnes";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("Erreur lors de la récupération des joueurs :", err);
            return res.status(500).send("Erreur serveur");
        }

        console.log("Joueurs récupérés :", results);
        res.render('statistiques_coach.html.twig', { joueurs: results });
    });
});
app.get('/comparaison', checkAuth, (req, res) => {
    const joueur1Id = req.query.joueur1;
    const joueur2Id = req.query.joueur2;
    const match1Id = req.query.match1 || 'global';
    const match2Id = req.query.match2 || 'global';

    db.query("SELECT * FROM Personnes WHERE id_personne = ?", [joueur1Id], (err, joueur1Result) => {
        if (err || joueur1Result.length === 0) {
            console.error("Erreur joueur 1 :", err);
            return res.status(500).send("Erreur serveur (joueur 1)");
        }

        db.query("SELECT * FROM Personnes WHERE id_personne = ?", [joueur2Id], (err, joueur2Result) => {
            if (err || joueur2Result.length === 0) {
                console.error("Erreur joueur 2 :", err);
                return res.status(500).send("Erreur serveur (joueur 2)");
            }

            db.query("SELECT id_feuille, date FROM Feuille_match WHERE id_personne = ?", [joueur1Id], (err, joueur1_matchs) => {
                if (err) {
                    console.error("Erreur récupération matchs joueur 1 :", err);
                    return res.status(500).send("Erreur serveur");
                }

                db.query("SELECT id_feuille, date FROM Feuille_match WHERE id_personne = ?", [joueur2Id], (err, joueur2_matchs) => {
                    if (err) {
                        console.error("Erreur récupération matchs joueur 2 :", err);
                        return res.status(500).send("Erreur serveur");
                    }

                    const statsQuery1 = match1Id === 'global'
                        ? `SELECT 
                                SUM(ace) AS ace, SUM(winner) AS winner, SUM(faute) AS faute, 
                                SUM(double_faute) AS double_faute, SUM(amorti) AS amorti, 
                                SUM(smash) AS smash, SUM(volee) AS volee, SUM(abandon) AS abandon 
                           FROM Feuille_match WHERE id_personne = ?`
                        : "SELECT * FROM Feuille_match WHERE id_feuille = ?";
                    const params1 = match1Id === 'global' ? [joueur1Id] : [match1Id];

                    db.query(statsQuery1, params1, (err, stats1) => {
                        if (err || stats1.length === 0) {
                            console.error("Erreur stats joueur 1 :", err);
                            return res.status(500).send("Erreur serveur ou stats 1 vides");
                        }

                        const statsQuery2 = match2Id === 'global'
                            ? `SELECT 
                                    SUM(ace) AS ace, SUM(winner) AS winner, SUM(faute) AS faute, 
                                    SUM(double_faute) AS double_faute, SUM(amorti) AS amorti, 
                                    SUM(smash) AS smash, SUM(volee) AS volee, SUM(abandon) AS abandon 
                               FROM Feuille_match WHERE id_personne = ?`
                            : "SELECT * FROM Feuille_match WHERE id_feuille = ?";
                        const params2 = match2Id === 'global' ? [joueur2Id] : [match2Id];

                        db.query(statsQuery2, params2, (err, stats2) => {
                            if (err || stats2.length === 0) {
                                console.error("Erreur stats joueur 2 :", err);
                                return res.status(500).send("Erreur serveur ou stats 2 vides");
                            }

                            // ✅ Correction ici : extraction de l'objet (stats[0])
                            const stats1Obj = stats1[0];
                            const stats2Obj = stats2[0];

                            res.render('comparaison.html.twig', {
                                joueur1: joueur1Result[0],
                                joueur2: joueur2Result[0],
                                joueur1_matchs,
                                joueur2_matchs,
                                stats1: stats1Obj,
                                stats2: stats2Obj,
                                selected_match1: match1Id,
                                selected_match2: match2Id
                            });
                        });
                    });
                });
            });
        });
    });
});




    function sumStats(feuilles) {
        const keys = ["ace", "winner", "faute", "double_faute", "amorti", "smash", "volee", "abandon"];
        const total = {};
        keys.forEach(k => total[k] = 0);
        feuilles.forEach(f => keys.forEach(k => total[k] += f[k] || 0));
        return total;
    }




// Route pour la saisie des données
app.get('/saisie-donnees', checkAuth, (req, res) => {
    if (req.session.statut !== 2) { // 2 = Accompagnateur
        return res.status(403).send("Accès interdit");
    }

    const sql = "SELECT id_personne, nom, prenom FROM Personnes";

    db.query(sql, (err, joueurs) => {
        if (err) {
            console.error("Erreur lors de la récupération des joueurs :", err);
            return res.status(500).send("Erreur serveur");
        }
        res.render('saisie-donnees.html.twig', { joueurs });
    });
});
app.post('/ajouter-feuille-match', checkAuth, (req, res) => {
    if (req.session.statut !== 2) { // Accompagnateur = 2
        return res.status(403).send("Accès interdit");
    }

    const { id_personne, ace, winner, faute, double_faute, amorti, smash, volee, abandon } = req.body;
    const dateMatch = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

    const sql = `INSERT INTO Feuille_match (id_personne, ace, winner, faute, double_faute, amorti, smash, volee, abandon, date) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(sql, [id_personne, ace, winner, faute, double_faute, amorti, smash, volee, abandon, dateMatch], (err, result) => {
        if (err) {
            console.error("Erreur lors de l'ajout de la feuille de match :", err);
            return res.status(500).send("Erreur serveur");
        }
        console.log("Feuille de match ajoutée avec succès !");
        res.redirect('/saisie-donnees'); 
    });
});





// Route des statistiques joueur
app.get('/statistiques_joueur', checkAuth, (req, res) => {
    if (req.session.statut !== 1) { // 1 = Joueur
        return res.status(403).send("Accès interdit");
    }

    const id_joueur = req.session.userId;
    db.query("SELECT * FROM Feuille_match WHERE id_personne = ?", [id_joueur], (err, stats) => {
        if (err) {
            console.error("Erreur MySQL:", err);
            return res.status(500).send("Erreur serveur");
        }
        res.render('statistiques_joueur.html.twig', { statistiques: stats });
    });
});


// Route de déconnexion
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error("Erreur lors de la déconnexion :", err);
            //return res.status(500).send("Erreur serveur lors de la déconnexion.");
        }
        res.clearCookie('connect.sid'); // 
        res.redirect('/');
    });
});

// Gestion des erreurs 404
app.use((req, res, next) => {
    console.log(`404 - Fichier non trouvé : ${req.url}`);
    res.status(404).send("Page non trouvée.");
});

// Lancement du serveur
server.listen(PORT, () => {
    console.log(`Serveur en écoute sur http://localhost:${PORT}`);
});
