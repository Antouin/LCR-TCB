const socket = io();
const messages = document.getElementById('messages');

socket.on('canal1', (msg) => {
    const item = document.createElement('li');
    item.textContent = msg;
    messages.appendChild(item);
    window.scrollTo(0, document.body.scrollHeight);
});
